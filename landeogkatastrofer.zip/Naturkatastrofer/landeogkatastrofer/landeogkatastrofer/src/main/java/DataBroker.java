import processing.core.PApplet;
import processing.data.Table;

import java.util.ArrayList;


public class DataBroker extends PApplet {
    PApplet p;
    Table data;
    ArrayList<Data> Datalist = new ArrayList<Data>();

    DataBroker(PApplet p, Table data){
        this.p = p;
        this.data = data;
    }

    public void loadData() {

        for(int i = 1; i < data.getRowCount(); ++i){
            for(int j = 2; j < data.getColumnCount(); ++j) {
                String country = data.getString( i ,1);
                int year = data.getInt(0, j);
                int deaths = data.getInt(i, j);
                Data myData = new Data(country, year, deaths);
                //Datalist.add(new Data(data.getString( i ,1),data.getInt(1, j), data.getInt(i, j) ));
                Datalist.add(myData);
                //println("land: " + data.getString( i ,1) + " år: " + data.getInt(0, j) + " døde: " + data.getInt(i, j));
                println("Land: " + myData.name + " År: " + myData.Year + " Døde: " + myData.Death);
            }
        }
    }
    public int getData(String countryName, int Year){
        int a = 0;
        for(int i = 0; i < Datalist.size(); ++i) {
            Data data = Datalist.get(i);
            if(countryName.equalsIgnoreCase(data.name) && Year == data.Year) {
                a = Datalist.get(i).Death;
            }
        }
        return a;
    }


}
