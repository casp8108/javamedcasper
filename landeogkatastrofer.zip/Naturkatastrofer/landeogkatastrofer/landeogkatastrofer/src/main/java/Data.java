public class Data {

    public String name;
    public int Year;
    public int Death;

    Data(String name, int Year, int Death){
        this.Death = Death;
        this.name = name;
        this.Year = Year;
    }
}
