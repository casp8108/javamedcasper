import processing.core.PApplet;
import processing.data.Table;

public class Axis {
    PApplet pApplet;
    int x1 , x2 , y2, y1, xSize;
    boolean isyAxis;
    float xInt;
    Table table;
    int maxY = Integer.MIN_VALUE;


    Axis(PApplet app, int x1 , int y1 , int x2 , int y2, boolean isyAxis, Table table, int xSize){
        pApplet = app;
        this.x1 = x1;
        this.x2 = x2;
        this.y1 = y1;
        this.y2 = y2;
        this.xSize = xSize;
        this.isyAxis = isyAxis;
        this.table = table;
        for (int i=0; i<table.getRowCount(); ++i)
            maxY = Math.max(table.getInt(i,1), maxY);


    }

    void draw(){
        pApplet.fill(255,0,0);
        pApplet.stroke(255,0,0);
        pApplet.line(x1,y1, x2, y2);
        xInt = xSize/table.getRowCount();

        if(isyAxis == true) {

            pApplet.triangle(x2  + 10, y2, x2 - 10, y2, x2, y2-10);
        }else{
            for (int i=0; i<xInt; ++i){
               
            }
         pApplet.triangle(x2+ 10, y2, x2, y2 + 10, x2, y2-10);



        }




    }
}
