import processing.core.PApplet;
import processing.data.Table;

public class Plot {
    PApplet pApplet;
    Table table;
    int xSize, ySize , posX, posY;
    Graph graph ;
    Axis xAxis;
    Axis yAxis;


    Plot(PApplet app, Table table , int posX, int posY, int xSize, int ySize){
        pApplet = app;
        this.table = table;
        this.xSize = xSize;
        this.ySize = ySize;
        this.posX = posX;
        this.posY = posY;

        graph = new Graph (pApplet, table, this.posX, this.posY, this.xSize, this.ySize);
        xAxis = new Axis (pApplet, this.posX , this.posY + this.ySize, this.posX + this.xSize, this.posY + this.ySize, false, table, xSize);
        yAxis = new Axis (pApplet, this.posX , posY + ySize , posX, posY, true, table, xSize);

    }

    void  draw(){
        pApplet.fill(255);
        pApplet.noStroke();
        pApplet.rect(posX, posY, xSize, ySize);

        pApplet.stroke(0);
        xAxis.draw();
        yAxis.draw();
        graph.draw();

        checkMouseCoordinates(pApplet.mouseX, pApplet.mouseY);


    }

    void  checkMouseCoordinates(int mouseX, int mouseY) {



        int row = graph.getRowFromMouse(mouseX, mouseY);
        if(row > 0 && row < table.getRowCount()) {
            pApplet.fill(255);
            pApplet.rect(mouseX, mouseY, 200,100);
            pApplet.fill(0);

            String msgDeaths = table.getString(row,2);
            String msgDate = table.getString(row,0);
            String msgCases = table.getString(row,1);

            pApplet.text("date: " + msgDate , mouseX + 10, mouseY + 30);
            pApplet.text("cases: " + msgCases, mouseX + 10, mouseY + 50);
            pApplet.text("deaths: " + msgDeaths, mouseX + 10, mouseY + 70);
        }


        pApplet.println(row);
    }
}
