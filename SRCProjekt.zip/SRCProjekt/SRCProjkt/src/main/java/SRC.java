import processing.core.PApplet;
import processing.core.PGraphics;
import processing.data.Table;
import processing.data.TableRow;

public class SRC extends PApplet {
    Table us;
    ToggleKnap minToggleKnap;
    AlmindeligKnap minAlmindeligeKnap;
    Plot graph;

    public static void main(String[] args) {
        PApplet.main("SRC");

    }


    @Override
    public void settings() {
        super.settings();
        fullScreen();
    }


    @Override
    public void setup() {
        super.setup();
        background(255);
        us = loadTable("us.csv");

        for(int i = 0; i < us.getColumnCount(); i++){
            print(i);
        }

        minToggleKnap   = new ToggleKnap(this,width - 50,50,25,25,"X");
        minAlmindeligeKnap = new AlmindeligKnap(this,200,350,200,50,"ALMINDELIG KNAP");
        graph = new Plot(this, us, width/8, height/3, (width - width/4), height/2);
    }


    @Override
    public void draw() {
        background(200);
        minToggleKnap.tegnKnap();

        fill(255, 0,0);
        textSize(30);
        text("COVID - 19 US DEATHS", 50,50);
        textSize(12);
        fill(255);

        graph.draw();

        if(minToggleKnap.erKlikket()) {
            exit();

        }

    }


    @Override
    public void mousePressed() {
        minToggleKnap.registrerKlik(mouseX,mouseY);
        minAlmindeligeKnap.registrerKlik(mouseX,mouseY);
    }


    @Override
    public void mouseReleased() {
        minAlmindeligeKnap.registrerRelease();
    }
}